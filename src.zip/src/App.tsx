import AllLevels from "./components/AllLevels";

function App() {
  return (
    <div className="App">
      <AllLevels />
    </div>
  );
}

export default App;
